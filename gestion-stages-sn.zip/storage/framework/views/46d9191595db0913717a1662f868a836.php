

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Liste des stages</h2>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('stages.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition">
            <i class="fas fa-plus mr-2"></i> Publier un stage
        </a>
    <?php endif; ?>
</div>

<!-- Filtres -->
<div class="bg-white p-4 rounded-lg shadow-md mb-6">
    <form method="GET" action="<?php echo e(route('stages.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <input type="text" name="search" placeholder="Rechercher un stage..." value="<?php echo e(request('search')); ?>" class="border rounded px-3 py-2">
        <select name="type" class="border rounded px-3 py-2">
            <option value="">Tous types</option>
            <option value="technique" <?php echo e(request('type')=='technique'?'selected':''); ?>>Technique</option>
            <option value="professionnel" <?php echo e(request('type')=='professionnel'?'selected':''); ?>>Professionnel</option>
            <option value="recherche" <?php echo e(request('type')=='recherche'?'selected':''); ?>>Recherche</option>
        </select>
        <select name="ville" class="border rounded px-3 py-2">
            <option value="">Toutes villes</option>
            <?php $__currentLoopData = \App\Models\Ville::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ville->id); ?>" <?php echo e(request('ville')==$ville->id?'selected':''); ?>><?php echo e($ville->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
            <i class="fas fa-filter"></i> Filtrer
        </button>
    </form>
</div>

<!-- Liste des stages -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
     <img src="<?php echo e(asset('images/stage-'.($loop->index % 3 + 1).'.jpg')); ?>" alt="Stage"> 
            <div class="p-5">
                <h4 class="text-lg font-bold text-green-700"><?php echo e($stage->titre); ?></h4>
                <p class="text-gray-600 text-sm"><?php echo e($stage->entreprise->nom); ?></p>
                <p class="text-gray-500 text-sm mt-1"><i class="fas fa-map-marker-alt text-red-500"></i> <?php echo e($stage->ville->nom); ?></p>
                <div class="flex justify-between items-center mt-3">
                    <span class="text-sm bg-blue-100 text-blue-700 px-2 py-1 rounded"><?php echo e($stage->type); ?></span>
                    <span class="text-sm font-semibold"><?php echo e($stage->remuneration ? $stage->montant_remuneration.' CFA' : 'Non rémunéré'); ?></span>
                </div>
                <a href="<?php echo e(route('stages.show', $stage)); ?>" class="mt-4 inline-block text-green-600 hover:underline text-sm font-medium">Voir détails →</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full text-center py-12 text-gray-500">
            <i class="fas fa-search text-4xl mb-3"></i>
            <p>Aucun stage trouvé.</p>
        </div>
    <?php endif; ?>
</div>

<div class="mt-6">
    <?php echo e($stages->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-stages-sn\resources\views/stages/index.blade.php ENDPATH**/ ?>