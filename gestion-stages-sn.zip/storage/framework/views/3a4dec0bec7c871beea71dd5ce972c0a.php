

<?php $__env->startSection('title', 'Gestion des stages - Admin'); ?>
<?php $__env->startSection('page-title', 'Stages'); ?>
<?php $__env->startSection('page-subtitle', 'Gestion des offres de stage'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="text" name="search" placeholder="🔍 Rechercher un stage..." value="<?php echo e(request('search')); ?>"
               class="border border-gray-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
        <select name="statut" class="border border-gray-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
            <option value="">Tous les statuts</option>
            <option value="ouvert" <?php echo e(request('statut')=='ouvert'?'selected':''); ?>>🟢 Ouvert</option>
            <option value="en_cours" <?php echo e(request('statut')=='en_cours'?'selected':''); ?>>🟡 En cours</option>
            <option value="ferme" <?php echo e(request('statut')=='ferme'?'selected':''); ?>>🔴 Fermé</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2.5 rounded-xl hover:bg-blue-700 transition">
            <i class="fas fa-filter mr-2"></i> Filtrer
        </button>
    </form>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Titre</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Entreprise</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ville</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Candidatures</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 font-medium text-gray-800"><?php echo e($stage->titre); ?></td>
                    <td class="px-6 py-4 text-gray-600"><?php echo e($stage->entreprise->nom ?? 'N/A'); ?></td>
                    <td class="px-6 py-4 text-gray-600"><?php echo e($stage->ville->nom ?? 'N/A'); ?></td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs rounded-full
                            <?php if($stage->statut == 'ouvert'): ?> bg-green-100 text-green-700
                            <?php elseif($stage->statut == 'en_cours'): ?> bg-yellow-100 text-yellow-700
                            <?php else: ?> bg-gray-100 text-gray-500 <?php endif; ?>">
                            <?php echo e(ucfirst($stage->statut)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <span class="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-semibold">
                            <?php echo e($stage->candidatures_count ?? 0); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-right">
                        <a href="<?php echo e(route('stages.show', $stage)); ?>" class="text-blue-600 hover:text-blue-800 mr-2">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('stages.edit', $stage)); ?>" class="text-yellow-600 hover:text-yellow-800 mr-2">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="<?php echo e(route('stages.destroy', $stage)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Supprimer ce stage ?')" class="text-red-600 hover:text-red-800">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-gray-500">
                        <i class="fas fa-briefcase text-4xl mb-3 block"></i>
                        Aucun stage trouvé
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-6">
    <?php echo e($stages->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-stages-sn\resources\views/admin/stages.blade.php ENDPATH**/ ?>