

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto">
    <div class="bg-white rounded-xl shadow-lg overflow-hidden">
        <div class="bg-gradient-to-r from-green-600 via-yellow-400 to-red-600 h-2"></div>
        
        <div class="p-8">
            <!-- En-tête -->
            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                <div class="flex items-center">
                   <?php if($entreprise->logo): ?>
    <img src="<?php echo e(asset('storage/' . $entreprise->logo)); ?>" 
         alt="<?php echo e($entreprise->nom); ?>" 
         class="h-20 w-20 rounded-full object-cover border-4 border-green-200">
<?php else: ?>
    <div class="h-20 w-20 rounded-full bg-gradient-to-r from-green-400 to-blue-400 flex items-center justify-center text-3xl text-white font-bold">
        <?php echo e(strtoupper(substr($entreprise->nom, 0, 2))); ?>

    </div>
<?php endif; ?>
                    <div class="ml-5">
                        <h1 class="text-2xl font-bold text-gray-800"><?php echo e($entreprise->nom); ?></h1>
                        <p class="text-gray-600">
                            <i class="fas fa-tag text-purple-500"></i> <?php echo e(ucfirst($entreprise->secteur_activite)); ?>

                            <span class="mx-2">•</span>
                            <i class="fas fa-users text-gray-400"></i> <?php echo e($entreprise->taille ?? 'Taille non précisée'); ?>

                        </p>
                    </div>
                </div>
                <div class="mt-4 md:mt-0 flex space-x-3">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <a href="<?php echo e(route('entreprises.edit', $entreprise)); ?>" 
                               class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm flex items-center">
                                <i class="fas fa-edit mr-2"></i> Modifier
                            </a>
                            <form action="<?php echo e(route('entreprises.destroy', $entreprise)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Supprimer cette entreprise ?')" 
                                        class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition text-sm flex items-center">
                                    <i class="fas fa-trash mr-2"></i> Supprimer
                                </button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Informations -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p class="text-xs text-gray-500 uppercase font-semibold">Email</p>
                    <p class="text-gray-700">
                        <i class="fas fa-envelope text-blue-500 mr-2"></i>
                        <a href="mailto:<?php echo e($entreprise->email); ?>" class="hover:text-blue-600"><?php echo e($entreprise->email); ?></a>
                    </p>
                </div>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p class="text-xs text-gray-500 uppercase font-semibold">Téléphone</p>
                    <p class="text-gray-700">
                        <i class="fas fa-phone text-green-500 mr-2"></i>
                        <a href="tel:<?php echo e($entreprise->telephone); ?>" class="hover:text-green-600"><?php echo e($entreprise->telephone); ?></a>
                    </p>
                </div>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <p class="text-xs text-gray-500 uppercase font-semibold">Localisation</p>
                    <p class="text-gray-700">
                        <i class="fas fa-map-marker-alt text-red-500 mr-2"></i>
                        <?php echo e($entreprise->ville->nom ?? 'N/A'); ?>, Sénégal
                    </p>
                </div>
                <div class="md:col-span-3 bg-gray-50 p-4 rounded-lg">
                    <p class="text-xs text-gray-500 uppercase font-semibold">Adresse</p>
                    <p class="text-gray-700"><?php echo e($entreprise->adresse); ?></p>
                </div>
                <?php if($entreprise->site_web): ?>
                    <div class="md:col-span-3 bg-gray-50 p-4 rounded-lg">
                        <p class="text-xs text-gray-500 uppercase font-semibold">Site Web</p>
                        <p class="text-gray-700">
                            <i class="fas fa-globe text-blue-500 mr-2"></i>
                            <a href="<?php echo e($entreprise->site_web); ?>" target="_blank" class="hover:text-blue-600"><?php echo e($entreprise->site_web); ?></a>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Description -->
            <?php if($entreprise->description): ?>
                <div class="mt-6 bg-gray-50 p-4 rounded-lg">
                    <h3 class="text-sm font-semibold text-gray-700 uppercase">Description</h3>
                    <p class="text-gray-600 mt-2"><?php echo e($entreprise->description); ?></p>
                </div>
            <?php endif; ?>

            <!-- Stages de l'entreprise -->
            <div class="mt-8">
                <h3 class="text-xl font-bold text-gray-800 flex items-center mb-4">
                    <i class="fas fa-briefcase text-green-600 mr-2"></i>
                    Stages proposés (<?php echo e($entreprise->stages->count()); ?>)
                </h3>
                <?php if($entreprise->stages->count() > 0): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php $__currentLoopData = $entreprise->stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                                <h4 class="font-semibold text-gray-800">
                                    <a href="<?php echo e(route('stages.show', $stage)); ?>" class="hover:text-green-600">
                                        <?php echo e($stage->titre); ?>

                                    </a>
                                </h4>
                                <p class="text-sm text-gray-500">
                                    <i class="fas fa-calendar mr-1"></i> 
value="<?php echo e(old('date_debut', isset($stage->date_debut) ? \Carbon\Carbon::parse($stage->date_debut)->format('Y-m-d') : '')); ?>"                                </p>
                                <span class="text-xs px-2 py-1 rounded-full
                                    <?php if($stage->statut == 'ouvert'): ?> bg-green-100 text-green-700
                                    <?php elseif($stage->statut == 'en_cours'): ?> bg-yellow-100 text-yellow-700
                                    <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                                    <?php echo e(ucfirst($stage->statut)); ?>

                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-sm">Cette entreprise n'a pas encore publié de stages.</p>
                <?php endif; ?>
            </div>

            <!-- Bouton retour -->
            <div class="mt-8 border-t border-gray-200 pt-6">
                <a href="<?php echo e(route('entreprises.index')); ?>" class="text-gray-600 hover:text-gray-800 transition flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Retour à la liste
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-stages-sn\resources\views/entreprises/show.blade.php ENDPATH**/ ?>