<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\gestion-stages-sn\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>