

<?php $__env->startSection('title', 'Modifier un utilisateur - Admin'); ?>
<?php $__env->startSection('page-title', 'Modifier un utilisateur'); ?>
<?php $__env->startSection('page-subtitle', 'Édition des informations'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nom complet *</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                           class="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                           class="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                    <input type="text" name="telephone" value="<?php echo e(old('telephone', $user->telephone)); ?>"
                           class="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Adresse</label>
                    <input type="text" name="adresse" value="<?php echo e(old('adresse', $user->adresse)); ?>"
                           class="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Rôle *</label>
                    <select name="role" required class="w-full border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
                        <option value="etudiant" <?php echo e($user->role == 'etudiant' ? 'selected' : ''); ?>>🎓 Étudiant</option>
                        <option value="entreprise" <?php echo e($user->role == 'entreprise' ? 'selected' : ''); ?>>🏢 Entreprise</option>
                        <?php if(auth()->user()->role == 'admin'): ?>
                            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>👑 Admin</option>
                        <?php endif; ?>
                    </select>
                    <?php if(auth()->id() == $user->id): ?>
                        <p class="text-xs text-yellow-600 mt-1">⚠️ Vous ne pouvez pas modifier votre propre rôle.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-100">
                <a href="<?php echo e(route('admin.users')); ?>" class="px-6 py-2.5 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition">
                    Annuler
                </a>
                <button type="submit" class="px-6 py-2.5 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl hover:from-green-700 hover:to-green-800 transition shadow-sm hover:shadow-md">
                    <i class="fas fa-save mr-2"></i> Enregistrer
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-stages-sn\resources\views/admin/users-edit.blade.php ENDPATH**/ ?>