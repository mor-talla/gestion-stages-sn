

<?php $__env->startSection('title', 'Gestion des utilisateurs - Admin'); ?>
<?php $__env->startSection('page-title', 'Utilisateurs'); ?>
<?php $__env->startSection('page-subtitle', 'Gestion des comptes'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-6">
    <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="text" name="search" placeholder="🔍 Rechercher par nom ou email..." value="<?php echo e(request('search')); ?>"
               class="border border-gray-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
        <select name="role" class="border border-gray-200 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-green-500 focus:border-transparent transition">
            <option value="">Tous les rôles</option>
            <option value="etudiant" <?php echo e(request('role')=='etudiant'?'selected':''); ?>>🎓 Étudiant</option>
            <option value="entreprise" <?php echo e(request('role')=='entreprise'?'selected':''); ?>>🏢 Entreprise</option>
            <option value="admin" <?php echo e(request('role')=='admin'?'selected':''); ?>>👑 Admin</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2.5 rounded-xl hover:bg-blue-700 transition">
            <i class="fas fa-filter mr-2"></i> Filtrer
        </button>
    </form>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rôle</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Téléphone</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Inscrit le</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 font-medium text-gray-800"><?php echo e($user->name); ?></td>
                    <td class="px-6 py-4 text-gray-600"><?php echo e($user->email); ?></td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs rounded-full
                            <?php if($user->role == 'admin'): ?> bg-yellow-100 text-yellow-700
                            <?php elseif($user->role == 'entreprise'): ?> bg-blue-100 text-blue-700
                            <?php else: ?> bg-green-100 text-green-700 <?php endif; ?>">
                            <?php if($user->role == 'admin'): ?> 👑 Admin
                            <?php elseif($user->role == 'entreprise'): ?> 🏢 Entreprise
                            <?php else: ?> 🎓 Étudiant <?php endif; ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-gray-600"><?php echo e($user->telephone ?? 'N/A'); ?></td>
                    <td class="px-6 py-4 text-gray-600"><?php echo e($user->created_at ? $user->created_at->format('d/m/Y') : 'N/A'); ?></td>
                    <td class="px-6 py-4 text-right">
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="text-blue-600 hover:text-blue-800 mr-3">
                            <i class="fas fa-edit"></i>
                        </a>
                        <?php if(auth()->id() !== $user->id): ?>
                            <form action="<?php echo e(route('admin.users.delete', $user)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Supprimer cet utilisateur ?')" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-gray-500">
                        <i class="fas fa-users text-4xl mb-3 block"></i>
                        Aucun utilisateur trouvé
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-6">
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestion-stages-sn\resources\views/admin/users.blade.php ENDPATH**/ ?>